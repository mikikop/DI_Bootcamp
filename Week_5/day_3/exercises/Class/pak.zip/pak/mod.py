def foo():
	print("foo")