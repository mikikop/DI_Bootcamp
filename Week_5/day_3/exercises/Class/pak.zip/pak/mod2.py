def blah():
	print("blah")


class Zap:

	def __init__(self):
		print("Zap!")