# **Solution of Flexbox Exercises**

## Exercise1
### What you had to reproduce :

![exercise_1](https://github.com/devtlv/PY1_2019/blob/master/Week1/CSS/Exercises/Flexbox_Exercise/exercise_1.png)

### The solution on codepen : 
> https://github.com/devtlv/PY2_JS_2019/blob/master/Week1/Day3.CSS/Solution_Exercises/solution_exercise1_flexbox.html


## Exercise2
### What you had to reproduce :

![exercise_2](https://github.com/devtlv/PY1_2019/blob/master/Week1/CSS/Exercises/Flexbox_Exercise/exercise_2.png)

### The solution on codepen : 
> https://github.com/devtlv/PY2_JS_2019/blob/master/Week1/Day3.CSS/Solution_Exercises/solution_exercise2_flexbox.html
